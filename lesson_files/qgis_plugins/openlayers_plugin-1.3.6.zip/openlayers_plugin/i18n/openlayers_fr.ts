<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fr">
<context>
    <name>Form</name>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="72"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="73"/>
        <source>Enable map</source>
        <translation>Activer la carte</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="74"/>
        <source>Add map</source>
        <translation>Ajouter la carte</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="75"/>
        <source>Hide cross in map</source>
        <translation>Masquer la croix sur la carte</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="76"/>
        <source>Refresh map</source>
        <translation>Actualiser la carte</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="77"/>
        <source>Save this image</source>
        <translation>Enregistrer cette image</translation>
    </message>
    <message>
        <location filename="ui_openlayers_ovwidget.py" line="78"/>
        <source>Copy rectangle (KML) of map to clipboard</source>
        <translation>Copiez rectangle (KML) de la carte dans le presse papier</translation>
    </message>
</context>
<context>
    <name>OpenLayersOverviewWidget</name>
    <message>
        <location filename="openlayers_ovwidget.py" line="235"/>
        <source>Save image</source>
        <translation>Enregistrer cette image</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="235"/>
        <source>Image(*.jpg)</source>
        <translation>Image(*.jpg)</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="248"/>
        <source>OpenLayers Overview</source>
        <translation>Vue d&apos;ensemble OpenLayers</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="158"/>
        <source>At least one layer in map canvas required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="248"/>
        <source>Error loading page!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="258"/>
        <source>Loading %1...</source>
        <translation>Lecture de 1% ...</translation>
    </message>
</context>
<context>
    <name>OpenlayersPlugin</name>
    <message>
        <location filename="openlayers_plugin.py" line="144"/>
        <source>OpenLayers Overview</source>
        <translation>Vue d&apos;ensemble OpenLayers</translation>
    </message>
    <message>
        <location filename="openlayers_plugin.py" line="154"/>
        <source>Add %1 layer</source>
        <translation>Ajouter %1</translation>
    </message>
    <message>
        <location filename="openlayers_plugin.py" line="161"/>
        <source>Could not set Google projection!</source>
        <translation>Impossible de définir la projection Google!</translation>
    </message>
</context>
</TS>
